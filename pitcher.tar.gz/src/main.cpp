// -------------------------------------------------
// Name: Mitchell Adam, Ryan Shukla
// ID: 1528592, 1537980
// CMPUT 275, Winter 2018
//
// Final Project
// -------------------------------------------------

#include "pitcher.h"

int main(int argc, char *argv[]) {
    // Run Pitcher
    pitcher(argc, argv);
}
